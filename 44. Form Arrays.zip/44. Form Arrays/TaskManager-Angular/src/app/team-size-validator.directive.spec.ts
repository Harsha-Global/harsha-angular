import { TeamSizeValidatorDirective } from './team-size-validator.directive';

describe('TeamSizeValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new TeamSizeValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
