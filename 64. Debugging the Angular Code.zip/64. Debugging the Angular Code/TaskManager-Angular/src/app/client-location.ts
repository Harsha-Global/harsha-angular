export class ClientLocation
{
    clientLocationID: any;
    clientLocationName: any;

    constructor()
    {
        this.clientLocationID = null;
        this.clientLocationName = null;
    }
}
