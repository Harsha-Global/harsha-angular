import { ClientLocationStatusValidatorDirective } from './client-location-status-validator.directive';

describe('ClientLocationStatusValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new ClientLocationStatusValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
