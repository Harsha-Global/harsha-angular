import { PagingPipe } from './paging.pipe';

describe('PagingPipe', () => {
  it('create an instance', () => {
    const pipe = new PagingPipe();
    expect(pipe).toBeTruthy();
  });
});
