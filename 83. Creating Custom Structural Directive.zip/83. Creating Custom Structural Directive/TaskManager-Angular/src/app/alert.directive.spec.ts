import { AlertDirective } from './alert.directive';

describe('AlertDirective', () => {
  it('should create an instance', () => {
    const directive = new AlertDirective();
    expect(directive).toBeTruthy();
  });
});
