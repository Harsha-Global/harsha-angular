import { RepeaterDirective } from './repeater.directive';

describe('RepeaterDirective', () => {
  it('should create an instance', () => {
    const directive = new RepeaterDirective();
    expect(directive).toBeTruthy();
  });
});
