import { SignUpViewModel } from './sign-up-view-model';

describe('SignUpViewModel', () => {
  it('should create an instance', () => {
    expect(new SignUpViewModel()).toBeTruthy();
  });
});
